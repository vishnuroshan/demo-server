/* eslint-disable no-undef */
module.exports = { PORT: process.env.PORT, KEY: process.env.KEY };