const authController = {};
const list = [
{ name: 'vishnu', role: 'NP', state: 'NY', dateActive: '18/07/2022', status: 'completed' },
{ name: 'gideon', role: 'NP,CNM', state: 'OZ', dateActive: '18/07/2022', status: 'notSubmitted' },
{ name: 'lorry', role: 'NP', state: 'NY', dateActive: '09/05/2022', status: 'completed' },
{ name: 'brad', role: 'NP,LLK,JHK,MNG', state: 'CA', dateActive: '09/09/2022', status: 'completed' },
{ name: 'max', role: 'NP,AR', state: 'NY', dateActive: '09/07/2022', status: 'notSubmitted' },
{ name: 'mary', role: 'NP', state: 'NY', dateActive: '22/07/2022', status: 'completed' },
{ name: 'vilma', role: 'NP,CCP,DNM,BPM,HJK', state: 'TX', dateActive: '09/09/2022', status: 'notSubmitted' },
{ name: 'gideon', role: 'NP,CNM', state: 'OZ', dateActive: '18/07/2022', status: 'notSubmitted' },
{ name: 'lorry', role: 'NP', state: 'NY', dateActive: '09/05/2022', status: 'completed' },
{ name: 'brad', role: 'NP,LLK,JHK,MNG', state: 'CA', dateActive: '09/09/2022', status: 'completed' },
{ name: 'max', role: 'NP,AR', state: 'NY', dateActive: '09/07/2022', status: 'notSubmitted' },
{ name: 'mary', role: 'NP', state: 'NY', dateActive: '22/07/2022', status: 'completed' },
{ name: 'vilma', role: 'NP,CCP,DNM,BPM,HJK', state: 'TX', dateActive: '09/09/2022', status: 'notSubmitted' },
{ name: 'gideon', role: 'NP,CNM', state: 'OZ', dateActive: '18/07/2022', status: 'notSubmitted' },
{ name: 'lorry', role: 'NP', state: 'NY', dateActive: '09/05/2022', status: 'completed' },
{ name: 'brad', role: 'NP,LLK,JHK,MNG', state: 'CA', dateActive: '09/09/2022', status: 'completed' },
{ name: 'max', role: 'NP,AR', state: 'NY', dateActive: '09/07/2022', status: 'notSubmitted' },
{ name: 'mary', role: 'NP', state: 'NY', dateActive: '22/07/2022', status: 'completed' },
{ name: 'vilma', role: 'NP,CCP,DNM,BPM,HJK', state: 'TX', dateActive: '09/09/2022', status: 'notSubmitted' },
{ name: 'gideon', role: 'NP,CNM', state: 'OZ', dateActive: '18/07/2022', status: 'notSubmitted' },
{ name: 'lorry', role: 'NP', state: 'NY', dateActive: '09/05/2022', status: 'completed' },
{ name: 'brad', role: 'NP,LLK,JHK,MNG', state: 'CA', dateActive: '09/09/2022', status: 'completed' },
{ name: 'max', role: 'NP,AR', state: 'NY', dateActive: '09/07/2022', status: 'notSubmitted' },
{ name: 'mary', role: 'NP', state: 'NY', dateActive: '22/07/2022', status: 'completed' },
{ name: 'vilma', role: 'NP,CCP,DNM,BPM,HJK', state: 'TX', dateActive: '09/09/2022', status: 'notSubmitted' },
{ name: 'gideon', role: 'NP,CNM', state: 'OZ', dateActive: '18/07/2022', status: 'notSubmitted' },
{ name: 'lorry', role: 'NP', state: 'NY', dateActive: '09/05/2022', status: 'completed' },
{ name: 'brad', role: 'NP,LLK,JHK,MNG', state: 'CA', dateActive: '09/09/2022', status: 'completed' },
{ name: 'max', role: 'NP,AR', state: 'NY', dateActive: '09/07/2022', status: 'notSubmitted' },
{ name: 'mary', role: 'NP', state: 'NY', dateActive: '22/07/2022', status: 'completed' },
{ name: 'vilma', role: 'NP,CCP,DNM,BPM,HJK', state: 'TX', dateActive: '09/09/2022', status: 'notSubmitted' },
{ name: 'gideon', role: 'NP,CNM', state: 'OZ', dateActive: '18/07/2022', status: 'notSubmitted' },
{ name: 'lorry', role: 'NP', state: 'NY', dateActive: '09/05/2022', status: 'completed' },
{ name: 'brad', role: 'NP,LLK,JHK,MNG', state: 'CA', dateActive: '09/09/2022', status: 'completed' },
{ name: 'max', role: 'NP,AR', state: 'NY', dateActive: '09/07/2022', status: 'notSubmitted' },
{ name: 'mary', role: 'NP', state: 'NY', dateActive: '22/07/2022', status: 'completed' },
{ name: 'vilma', role: 'NP,CCP,DNM,BPM,HJK', state: 'TX', dateActive: '09/09/2022', status: 'notSubmitted' },
{ name: 'gideon', role: 'NP,CNM', state: 'OZ', dateActive: '18/07/2022', status: 'notSubmitted' },
{ name: 'lorry', role: 'NP', state: 'NY', dateActive: '09/05/2022', status: 'completed' },
{ name: 'brad', role: 'NP,LLK,JHK,MNG', state: 'CA', dateActive: '09/09/2022', status: 'completed' },
{ name: 'max', role: 'NP,AR', state: 'NY', dateActive: '09/07/2022', status: 'notSubmitted' },
{ name: 'mary', role: 'NP', state: 'NY', dateActive: '22/07/2022', status: 'completed' },
{ name: 'vilma', role: 'NP,CCP,DNM,BPM,HJK', state: 'TX', dateActive: '09/09/2022', status: 'notSubmitted' },
{ name: 'gideon', role: 'NP,CNM', state: 'OZ', dateActive: '18/07/2022', status: 'notSubmitted' },
{ name: 'lorry', role: 'NP', state: 'NY', dateActive: '09/05/2022', status: 'completed' },
{ name: 'brad', role: 'NP,LLK,JHK,MNG', state: 'CA', dateActive: '09/09/2022', status: 'completed' },
{ name: 'max', role: 'NP,AR', state: 'NY', dateActive: '09/07/2022', status: 'notSubmitted' },
{ name: 'mary', role: 'NP', state: 'NY', dateActive: '22/07/2022', status: 'completed' },
{ name: 'vilma', role: 'NP,CCP,DNM,BPM,HJK', state: 'TX', dateActive: '09/09/2022', status: 'notSubmitted' },
{ name: 'gideon', role: 'NP,CNM', state: 'OZ', dateActive: '18/07/2022', status: 'notSubmitted' },
{ name: 'lorry', role: 'NP', state: 'NY', dateActive: '09/05/2022', status: 'completed' },
{ name: 'brad', role: 'NP,LLK,JHK,MNG', state: 'CA', dateActive: '09/09/2022', status: 'completed' },
{ name: 'max', role: 'NP,AR', state: 'NY', dateActive: '09/07/2022', status: 'notSubmitted' },
{ name: 'mary', role: 'NP', state: 'NY', dateActive: '22/07/2022', status: 'completed' },
{ name: 'vilma', role: 'NP,CCP,DNM,BPM,HJK', state: 'TX', dateActive: '09/09/2022', status: 'notSubmitted' },
{ name: 'gideon', role: 'NP,CNM', state: 'OZ', dateActive: '18/07/2022', status: 'notSubmitted' },
{ name: 'lorry', role: 'NP', state: 'NY', dateActive: '09/05/2022', status: 'completed' },
{ name: 'brad', role: 'NP,LLK,JHK,MNG', state: 'CA', dateActive: '09/09/2022', status: 'completed' },
{ name: 'max', role: 'NP,AR', state: 'NY', dateActive: '09/07/2022', status: 'notSubmitted' },
{ name: 'mary', role: 'NP', state: 'NY', dateActive: '22/07/2022', status: 'completed' },
{ name: 'vilma', role: 'NP,CCP,DNM,BPM,HJK', state: 'TX', dateActive: '09/09/2022', status: 'notSubmitted' }
]
authController.forgotPassword = ({ email }) => {
	if (email === 'frg200@gmail.com') return { status: 200, detail: 'mail sent to email. please check' };
	if (email === 'frg404@gmail.com') return { status: 404, detail: 'email not found' };
	if (email === 'frg500@gmail.com') return { status: 500, detail: 'something went wrong' };
};

authController.login = ({ username, password }) => {
	if (username === 'frg200@gmail.com') return { status: 200, detail: 'successful', jwt: 'some random jwt token' };
	if (username === 'frg404@gmail.com') return { status: 404, detail: 'user not found' };
	if (username === 'frg401@gmail.com') return { status: 401, detail: 'unauthorized' };
	if (username === 'frg500@gmail.com') return { status: 500, detail: 'something went wrong' };
};
authController.resetPassword = ({ token, oldPassword, newPassword }) => {
	if (token === '200' || 'reset-token') return { status: 200, detail: 'successful' };
	if (token === '404') return { status: 404, detail: 'unauthorized' };
	if (token === '500') return { status: 401, detail: 'something went wrong!' };
};

authController.verifyUser = ({ token }) => {
	if (token === '200') return { status: 200, detail: 'successful', jwt: 'reset-token' };
	if (token === '404') return { status: 404, detail: 'unauthorized' };
	if (token === '500') return { status: 401, detail: 'something went wrong!' };
};

authController.listApi = ({ page, limit, search }) => {
	if (page === 0) page = 1;
	return { limit: Number(limit), totalRecords: list.length, page: Number(page), list: list.slice((page - 1) * limit, page * limit) }
};

authController.listing
module.exports = authController;