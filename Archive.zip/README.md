# node-api
basic node api

please create .env file in root folder.

create a dabase in postgres as in DATABASE_NAME


```
npm i

npm start
```

custom port

```
npm start <custom port number>
```


### sample .env properties
KEY=
PORT=
DATABASE_NAME=
DATABASE_USER=
DATABASE_PASS=
DATABASE_HOST=