const router = require('express').Router();
const authController = require('../controllers/auth');


router.get('/api/ping', (request, response) => {
	response.set('Access-Control-Allow-Origin', 'http://localhost:4200/');
	response.status(200).json({ message: 'pong' });
});

router.post('/api/forgot-password', (request, response) => {
	const result = authController.forgotPassword(request.body)
	response.set('Access-Control-Allow-Origin', 'http://localhost:4200/');
	response.status(result.status).json(result);
});

router.post('/api/login', (request, response) => {
	const result = authController.login(request.body);
	response.set('Access-Control-Allow-Origin', 'http://localhost:4200/');
	response.status(result.status).json(result);
});
router.post('/api/reset-password', (request, response) => {
	response.set('Access-Control-Allow-Origin', 'http://localhost:4200/');
	const result = authController.resetPassword(request.body);
	response.status(result.status).json(result);
});

router.post('/api/verify-user', (request, response) => {
	response.set('Access-Control-Allow-Origin', 'http://localhost:4200/');
	const result = authController.verifyUser(request.body);
	response.status(result.status).json(result);
});

router.get('/api/list', (request, response) => {
	response.set('Access-Control-Allow-Origin', 'http://localhost:4200/');
	const result = authController.listApi(request.query);
	response.status(200).json({ status: 200, ...result });
});
module.exports = router;